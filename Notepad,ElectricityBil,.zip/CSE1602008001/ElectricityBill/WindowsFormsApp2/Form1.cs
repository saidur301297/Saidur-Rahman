﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {

        Double peak = 0;
        Double offhour = 0;
        Double total = 0;
        Double r = 0;
        Double k = 0;
        Double peaktime=0;
        Double offtime = 0;
        Double m = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void calculationBtn_Click(object sender, EventArgs e)
        {
            if (residentialRadio.Checked)
            {
                r = 0.053;
               
                peak = Double.Parse(peakHours.Text);

                offhour = Double.Parse(offPeakHours.Text);
                total = 10 + peak * r;
                totalBill.Text = total.ToString();
            }
            else if (commercialRadio.Checked)
            {
                r = 0.042;
                peak = Double.Parse(peakHours.Text);
                if (peak >= 800)
                {
                    k = peak - 800;
                    total = 50 + k * r;
                }
                else
                {
                    total = 50;
                }
 
                totalBill.Text = total.ToString();
            }
            else
            {
                r = 0.062;
                peak = Double.Parse(peakHours.Text);
                offhour = Double.Parse(offPeakHours.Text);
                if (peak >= 800)
                {
                    k = peak - 800;
                    peaktime = 70 + k * r;
                    
                }
                if (offhour >= 800)
                {
                    m = offhour - 800;
                    offtime = 35 + m * .025;
                    total = peaktime + offtime; 
                }
                               
                    else
                {
                    total = 70+35;
                }
 
                   totalBill.Text = total.ToString();

                }
                
            }
            
            
            
            
   

        }
    }

