﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.residentialRadio = new System.Windows.Forms.RadioButton();
            this.commercialRadio = new System.Windows.Forms.RadioButton();
            this.industrialRadio = new System.Windows.Forms.RadioButton();
            this.peakHours = new System.Windows.Forms.TextBox();
            this.offPeakHours = new System.Windows.Forms.TextBox();
            this.calculationBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.totalBill = new System.Windows.Forms.TextBox();
            this.connectionGroupBox = new System.Windows.Forms.GroupBox();
            this.connectionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // residentialRadio
            // 
            this.residentialRadio.AutoSize = true;
            this.residentialRadio.Location = new System.Drawing.Point(34, 28);
            this.residentialRadio.Name = "residentialRadio";
            this.residentialRadio.Size = new System.Drawing.Size(77, 17);
            this.residentialRadio.TabIndex = 0;
            this.residentialRadio.TabStop = true;
            this.residentialRadio.Text = "Residential";
            this.residentialRadio.UseVisualStyleBackColor = true;
            // 
            // commercialRadio
            // 
            this.commercialRadio.AutoSize = true;
            this.commercialRadio.Location = new System.Drawing.Point(34, 76);
            this.commercialRadio.Name = "commercialRadio";
            this.commercialRadio.Size = new System.Drawing.Size(79, 17);
            this.commercialRadio.TabIndex = 1;
            this.commercialRadio.TabStop = true;
            this.commercialRadio.Text = "Commercial";
            this.commercialRadio.UseVisualStyleBackColor = true;
            // 
            // industrialRadio
            // 
            this.industrialRadio.AutoSize = true;
            this.industrialRadio.Location = new System.Drawing.Point(34, 126);
            this.industrialRadio.Name = "industrialRadio";
            this.industrialRadio.Size = new System.Drawing.Size(67, 17);
            this.industrialRadio.TabIndex = 2;
            this.industrialRadio.TabStop = true;
            this.industrialRadio.Text = "Industrial";
            this.industrialRadio.UseVisualStyleBackColor = true;
            // 
            // peakHours
            // 
            this.peakHours.Location = new System.Drawing.Point(514, 100);
            this.peakHours.Name = "peakHours";
            this.peakHours.Size = new System.Drawing.Size(100, 20);
            this.peakHours.TabIndex = 3;
            // 
            // offPeakHours
            // 
            this.offPeakHours.Location = new System.Drawing.Point(514, 154);
            this.offPeakHours.Name = "offPeakHours";
            this.offPeakHours.Size = new System.Drawing.Size(100, 20);
            this.offPeakHours.TabIndex = 3;
            // 
            // calculationBtn
            // 
            this.calculationBtn.ForeColor = System.Drawing.Color.DarkGreen;
            this.calculationBtn.Location = new System.Drawing.Point(285, 248);
            this.calculationBtn.Name = "calculationBtn";
            this.calculationBtn.Size = new System.Drawing.Size(105, 27);
            this.calculationBtn.TabIndex = 4;
            this.calculationBtn.Text = "Calculation";
            this.calculationBtn.UseVisualStyleBackColor = true;
            this.calculationBtn.Click += new System.EventHandler(this.calculationBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(410, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Peak Hours";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(410, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Off peak Hours";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(183, 303);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Total Bill";
            // 
            // totalBill
            // 
            this.totalBill.Location = new System.Drawing.Point(283, 302);
            this.totalBill.Name = "totalBill";
            this.totalBill.Size = new System.Drawing.Size(107, 20);
            this.totalBill.TabIndex = 3;
            // 
            // connectionGroupBox
            // 
            this.connectionGroupBox.Controls.Add(this.industrialRadio);
            this.connectionGroupBox.Controls.Add(this.commercialRadio);
            this.connectionGroupBox.Controls.Add(this.residentialRadio);
            this.connectionGroupBox.ForeColor = System.Drawing.Color.Yellow;
            this.connectionGroupBox.Location = new System.Drawing.Point(75, 27);
            this.connectionGroupBox.Name = "connectionGroupBox";
            this.connectionGroupBox.Size = new System.Drawing.Size(155, 165);
            this.connectionGroupBox.TabIndex = 7;
            this.connectionGroupBox.TabStop = false;
            this.connectionGroupBox.Text = "Connection Type";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.connectionGroupBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.calculationBtn);
            this.Controls.Add(this.totalBill);
            this.Controls.Add(this.offPeakHours);
            this.Controls.Add(this.peakHours);
            this.Name = "Form1";
            this.Text = "Form1";
            this.connectionGroupBox.ResumeLayout(false);
            this.connectionGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton residentialRadio;
        private System.Windows.Forms.RadioButton commercialRadio;
        private System.Windows.Forms.RadioButton industrialRadio;
        private System.Windows.Forms.TextBox peakHours;
        private System.Windows.Forms.TextBox offPeakHours;
        private System.Windows.Forms.Button calculationBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox totalBill;
        private System.Windows.Forms.GroupBox connectionGroupBox;
    }
}

